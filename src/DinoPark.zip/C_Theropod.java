/** Alejandro Mijares
 * March 26, 2023
 * Panther ID: 3145563
 * Program Version: 1.0
 * Java Version: 8
 */
public class C_Theropod extends Carnivore{

    public C_Theropod(String setName, int setSize, String setAscii, String setTidbit, String setTimePeriod) {
        super(setName, setSize, setAscii, setTidbit, setTimePeriod);
    }
}

/** Alejandro Mijares
 * March 26, 2023
 * Panther ID: 3145563
 * Program Version: 1.0
 * Java Version: 8
 */
public class H_Sauropod extends Herbivore{
    public H_Sauropod(String setName, int setSize, String setAscii, String setTidbit, String setTimePeriod) {
        super(setName, setSize, setAscii, setTidbit, setTimePeriod);
    }
}
